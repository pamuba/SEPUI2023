import React from 'react';
// import UserListItem from './UserListItem';
import {Button, ListGroup, ListGroupItem} from 'reactstrap';

const UserList = ({users, onDeleteUser}) => {
    return (
        <ListGroup>
            {users.sort((a, b) => {
                if (a.username > b.username) {
                    return 1;
                } else if (a.username < b.username) {
                    return -1;
                } else if (a.name > b.name) {
                    return 1;
                } else if (a.name < b.name) {
                    return -1;
                }
                return 0;
            }).map((user) => {
                return (
                    <ListGroupItem key={user.id}>
                        <section style={{display:'flex'}}>
                            <div style={{flexGrow:1, margin:'auto 0'}}>
                            {user.username} {user.name}
                            </div>
                            <div>
                            <Button outline color='danger' onClick={()=>onDeleteUser(user.id)}>Delete</Button>
                            </div>
                        </section>
                       
                        {/* <UserListItem onDeleteClick={onDeleteUserClick} user={user}/> */}
                    </ListGroupItem>
                );
            })}
        </ListGroup>
    );
};

export default UserList;