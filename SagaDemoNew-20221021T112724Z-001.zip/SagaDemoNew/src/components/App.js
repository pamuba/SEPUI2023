import React, {Component} from 'react'
import {connect} from 'react-redux'
import { getUsersRequest, createUserRequest, deleteUserRequest, usersError } from '../actions/users';
import NewUserForm from './NewUserForm';
import UserList from './UsersList';
import {Alert} from 'reactstrap';

class App extends Component {
  constructor(props) {
    super(props)
    this.props.getUsersRequest()
  }
  handleCloseAlert = () => {
    this.props.usersError({
        error: ''
    });
  };
  handleSubmit = ({username, name})=>{
    // console.log(username, name)
    this.props.createUserRequest({
      username, name
    })
  }
  handleDeleteUserClick = (userId) => {
    this.props.deleteUserRequest(userId);
  };
  render(){
    const users = this.props.users
    console.log(users)
    return (
     
      <div style={{margin:'0 auto', padding:'20px', maxWidth:'600px'}}>
        <h2>
            Users
        </h2>
        <Alert color="danger" isOpen={!!this.props.users.error} toggle={this.handleCloseAlert}>
            {this.props.users.error}
        </Alert>
        <NewUserForm onSubmit={this.handleSubmit}/>
        <UserList onDeleteUser={this.handleDeleteUserClick} users={users.items}></UserList>
      </div>
     
    );
  }
}

export default connect(({users})=>({users}), {
  getUsersRequest,
  createUserRequest,
  deleteUserRequest,
  usersError
})(App);
